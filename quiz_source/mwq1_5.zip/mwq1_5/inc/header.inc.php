<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<title><?php if (!testsub) { echo 'Test Zone'; } else { echo $testsub.' Test'; } ?></title>
<meta name="DESCRIPTION" CONTENT="Multi Web Vista web development and localisation solutions as well as server-side applications such as online quiz systems.">
<meta name="keywords" CONTENT="Web design, Quiz System, web site design, multilingual web sites, Dreamweaver, Ultradev, web developer, Internet design, web graphics, imaging, photo editing, data-driven web sites, shopping carts, translations, traduzioni, &Uuml;bersetzungen, localisation, localization, Fife, Scotland, Dunfermline, Edinburgh, UK, small businesses">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="multiteststyle.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div class="mainheader" id="heading">MultiWebTest: Please Replace This Header</h1></div>
