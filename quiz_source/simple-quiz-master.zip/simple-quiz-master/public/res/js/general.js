$(function() {
    $('#updater').fadeIn('slow').delay(2000).fadeOut('slow');
});
