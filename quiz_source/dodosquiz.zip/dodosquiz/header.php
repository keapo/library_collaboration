<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<!-- this is the header of your quiz file. 
$quiz_question is your html page title.
Remove that will result in lost of the title -->
<html>
<head>
<title><?=$quiz_question?></title>
<style type="text/css" media="screen">@import "quiz.css";</style>
</head>

<body>

<div id="Header">&nbsp;</div>

<div id="Content">
	