</div>

<div id="Menu">
	<a href="dodosquiz.php?n=1" title="Are you the one for Dodo?">Are you the one for Dodo?</a><br>
	<a href="dodosquiz.php?n=2" title="Will you like to take another quiz?">Will you like to take anthor quiz?</a><br>
	<a href="dodosquiz.php?n=3" title="Quiz Type II">How well do you know math?</a><br>
	<br>
	<a href="readme.html" title="read me">Read Me</a><br>
	<br>
	<a href="http://regretless.com/scripts/" title="Get more scripts here!">Dodo's Scripts Collection</a><br>
	<br>
</div>

<!-- BlueRobot was here. -->

</body>
</html>