<?php


namespace SimpleQuiz\Utils\User;


use SimpleQuiz\Utils\Base\User;

class GuestUser extends User{

    private $name = 'Guest';

}